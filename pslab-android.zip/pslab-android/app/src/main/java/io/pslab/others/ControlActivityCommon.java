package io.pslab.others;

import java.util.HashMap;

/**
 * Created by AVJEET on 16-02-2018.
 */

public class ControlActivityCommon {
    public static HashMap<String , Float> editTextValues ;

    public ControlActivityCommon(){
        editTextValues= new HashMap<>();
    }

}
