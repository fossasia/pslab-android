package io.pslab.interfaces;

/**
 * created by VIKAS9899 on 14/05/2020
 */
public interface OperationCallback {
    void playData();
    void stopData();
    void saveGraph();
}
